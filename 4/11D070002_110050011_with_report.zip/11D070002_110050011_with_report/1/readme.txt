To run the code, navigate to the Code/ directory in MATLAB and run 'myDriver'.

Team: Ashray Malhotra, Rohan Prinja