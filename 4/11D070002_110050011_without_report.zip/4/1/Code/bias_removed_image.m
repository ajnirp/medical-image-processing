[r, c, ~] = size(memb);
prod = zeros(r,c);
for i=1:r
    for j=1:c       
        prod(i,j) = reshape(memb(i,j,:), [1 3])*class;
    end
end